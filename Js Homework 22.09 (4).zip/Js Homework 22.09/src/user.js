console.log('User page loaded');
